# ==============================================================================
# Google Colab 1-Click APK Builder for Kivy with Arabic Reshaper
# Run this on free Google Colab (Runtime -> Change runtime type -> Python 3)
# ==============================================================================

# 1. Install system tools & libraries required by Buildozer
!sudo apt update -q
!sudo apt install -y -q git zip unzip openjdk-17-jdk autoconf libtool pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev libtinfo5 cmake libffi-dev libssl-dev ccache

# 2. Install Buildozer and Cython compatible with Kivy recipes
!pip install --upgrade "Cython<3.0" buildozer # or Cython==0.29.36

# 3. Create project directory and prepare files
import os
os.makedirs("kivy_project", exist_ok=True)
%cd kivy_project

# 4. Download Arabic font (Cairo) if not provided
!curl -s -L -o Cairo-Regular.ttf "https://raw.githubusercontent.com/googlefonts/cairo/main/fonts/ttf/Cairo-Regular.ttf"

# 5. Build the Android debug APK (automatically accepts SDK licenses)
!yes | buildozer android debug

# 6. Copy APK to Google Drive or download directly to your computer!
from google.colab import files
import glob

apk_files = glob.glob("bin/*.apk")
if apk_files:
    print(f"\nBuild successful! Found: {apk_files[0]}")
    files.download(apk_files[0])
else:
    print("\nBuild failed or APK not found in bin/ directory.")
