# -*- coding: utf-8 -*-
"""
Helper module for handling Arabic text in Kivy applications.
Usage:
    from arabic_helper import ar, get_arabic_font
    
    btn = Button(text=ar("مرحباً بك"), font_name=get_arabic_font())
"""
import os
import arabic_reshaper
from bidi.algorithm import get_display

# List of preferred Arabic fonts to look for in the project directory
PREFERRED_FONTS = [
    'Cairo-Regular.ttf',
    'Amiri-Regular.ttf',
    'NotoSansArabic-Regular.ttf',
    'arial.ttf'
]

def ar(text: str) -> str:
    """
    Transforms raw Arabic string into reshaped, bidirectional ordered text.
    Handles None and empty strings safely.
    """
    if not text:
        return ""
    try:
        reshaped = arabic_reshaper.reshape(text)
        return get_display(reshaped)
    except Exception as e:
        print(f"Arabic reshape error: {e}")
        return text

def get_arabic_font() -> str:
    """
    Returns the first available Arabic font found in the working directory,
    or falls back to 'Roboto'.
    """
    for font in PREFERRED_FONTS:
        if os.path.exists(font):
            return font
    return 'Roboto'
