# MyKivyApp (Kivy Arabic Android Project)

مشروع تطبيق أندرويد مبني باستخدام Kivy مع دعم كامل للنصوص والخطوط العربية.

## الملفات المضمنة:
- `main.py`: كود التطبيق الأساسي مع دالة معالجة اللغة العربية `ar()`.
- `buildozer.spec`: إعدادات الحزم والمتطلبات والصلاحيات لـ Buildozer.
- `.gitlab-ci.yml`: خط تجميع تلقائي لـ GitLab CI باستخدام `kivy/buildozer:latest`.
- `.github/workflows/android.yml`: خط تجميع لـ GitHub Actions.
- `arabic_helper.py`: وحدة بايثون لمعالجة النصوص العربية وربط الحروف.
- `build_colab.py`: سكريبت لتجميع ملف APK مجاناً عبر Google Colab.

## 📱 الخطوات لبناء ملف APK:

### الطريقة 1: عبر GitLab CI (تلقائياً)
1. قم بإنشاء مستودع جديد على GitLab وادفع هذا المجلد إليه:
   ```bash
   git init
   git add .
   git commit -m "Initial Kivy Android project"
   git remote add origin <your-gitlab-repo-url>
   git push -u origin main
   ```
2. سيبدأ GitLab CI تلقائياً في بناء حزمة APK وتحميلها في قسم Artifacts!

### الطريقة 2: عبر Google Colab (مجاناً وبسرعة)
1. افتح https://colab.research.google.com
2. الصق كود `build_colab.py` وشغل الخلية.
3. سيتم تنزيل ملف الـ APK لجهازك فور انتهاء التجميع!

### الطريقة 3: محلياً على نظام Linux
```bash
pip install --upgrade Cython==0.29.36 buildozer
buildozer android debug
```

---
تم إنشاؤه بواسطة KivyDroid Studio
