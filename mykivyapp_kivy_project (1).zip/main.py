# -*- coding: utf-8 -*-
"""
Kivy Mobile Application with Arabic Support
Configured for Android build via Buildozer
"""
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.core.window import Window
import arabic_reshaper
from bidi.algorithm import get_display

def ar(text: str) -> str:
    """Reshapes Arabic text and applies BiDi algorithm for Kivy rendering"""
    if not text:
        return ""
    reshaped = arabic_reshaper.reshape(text)
    return get_display(reshaped)

class MyApp(App):
    def build(self):
        # Window background color (optional)
        # Window.clearcolor = (0.07, 0.09, 0.15, 1)

        layout = BoxLayout(orientation='vertical', padding=20, spacing=15)
        
        # Arabic-compatible Button widget
        btn = Button(
            text=ar("مرحباً بك في تطبيقي"),
            font_name="Cairo-Regular.ttf",
            font_size="22sp",
            size_hint=(1, 0.4),
            background_normal="",
            background_color=(0.14, 0.48, 0.88, 1) # #2563EB
        )
        btn.bind(on_press=self.on_button_click)
        
        layout.add_widget(btn)
        return layout

    def on_button_click(self, instance):
        print("Button pressed in Kivy Android app!")
        instance.text = ar("تم الضغط بنجاح! ✓")

if __name__ == '__main__':
    MyApp().run()
